#include<iostream>
using std::cout;
using std::endl;
#include<cmath>
#include"de.h"

struct Sine : public DE
{
	Sine(double deltat) : DE(2,deltat) {}
	virtual void step( const vector<double>& y, vector<double>& dydt ) {
		const double pi = 3.141592654;
		dydt[0] = y[1];
		dydt[1] = -y[0];
	}
};

struct Expo : public DE
{
	Expo(double deltat) : DE(1,deltat) {}
	virtual void step ( const vector<double>& y, vector<double>& dydt ) {
		dydt[0] = y[0];
	}
};

int main(void)
{
	const double pi = 3.141592654;
	double deltat = pi/100;
	Sine sine(deltat);
	sine.y[0] = 0;    sine.y[1]    = 1;
	sine.dydt[0] = 1; sine.dydt[1] = 0;
	for( double t=0; t<2*pi; t+=pi/100 ) {
		cout<<t<<"\t"<<sine.y[0]<<"\t"<<sine.y[1]<<endl;
		sine.rk4();
	}
	Expo expo(deltat); expo.y[0] = 1; expo.dydt[0] = 1;
	for( double t=0; t<10; t+=.1 ) {
		cout<<t<<"\t"<<expo.y[0]<<endl;
		expo.rk4();
	}
	return 0;
};
