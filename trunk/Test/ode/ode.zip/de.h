#ifndef DIFFEQN
#define DIFFEQN

#include<vector>
using std::vector;

class DE
{
	DE(void);
	DE(DE&);
	void operator=(DE&);
protected:
	int n; // dimension of system == y.size() == dydt.size()
	double deltat;
	double hh;
	double h6;

	vector<double> dym;
	vector<double> dyt;
	vector<double> yt;

	// define dydt here
	virtual void step( const vector<double>& y, vector<double>& dydt ) = 0;
public:
	vector<double> y;
	vector<double> dydt;

	DE( int n, double deltat )
		: n(n), deltat(deltat), hh(deltat/2.), h6(deltat/6.),
		  y(n), dydt(n), dym(n), dyt(n), yt(n) {}
	virtual ~DE(void) {}

	void rk4(void) {
		for( int i=0; i<n; i++ )
			yt[i] = y[i] +hh*dydt[i];
		step(yt,dyt);
		for( int i=0; i<n; i++ )
			yt[i] = y[i] +hh*dyt[i];
		step(yt,dym);
		for( int i=0; i<n; i++ ) {
			yt[i] = y[i] +deltat*dym[i];
			dym[i] += dyt[i];
		}
		step(yt,dyt);
		for( int i=0; i<n; i++ )
			y[i] += h6*( dydt[i] +dyt[i] +2.*dym[i] );
	}
};

#endif
